﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelcomeAcademy6.DataModel
{
    public class MainEnumerators
    {
       public enum StartMenuFunctions
        {
           None = 0,
           InsertWorker,
           InsertWorkerWeek,
           DeleteWorker,
           ShowWorkers,
           SearchWorkers,
           ImportWorkers,
           ExitProgram,
           SaveWorkersList,
           StoryInfo,
        }
        public enum Role
        {
           operaio = 1,
           impiegato
           
        }
        public enum Department
        {
            [Description("Ufficio Acquisti")]
            UfficioAcquisti = 1,
            [Description("Assemblaggio Motore")]
            AssemblaggioMotore,
            [Description("Ufficio Controllo Qualità")]
            UfficioControlloQualità,
            [Description("Contabilità")]
            Contabilita,
            [Description("Manutenzione")]
            Manutenzione
        }
    }
}
