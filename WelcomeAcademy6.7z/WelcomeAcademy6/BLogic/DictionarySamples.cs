﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelcomeAcademy6.BLogic
{
    internal class DictionarySamples
    {
        internal void FirstDictionary()
        {
        Dictionary<string,int > valuePairs = new Dictionary<string,int>();
            valuePairs.Add("test", 47);
            valuePairs.Add("test1", 45);
            valuePairs.Add("test2", 42);
            if(valuePairs.ContainsKey("test"))
               Console.WriteLine("TEST  é NELLA NOSTRA LISTA");
            Console.WriteLine();

            SortedDictionary<string,int> valuePairsSorted = new SortedDictionary<string,int>();
            valuePairsSorted.Add("Giada", 30);
            valuePairsSorted.Add("GiadMara", 47);
            valuePairsSorted.Add("GiadaMMM", 31);

            foreach (KeyValuePair<string,int> pair in valuePairsSorted) 
                Console.WriteLine($"Nome: {pair.Key} - Età : {pair.Value}");
        }
    }
}
