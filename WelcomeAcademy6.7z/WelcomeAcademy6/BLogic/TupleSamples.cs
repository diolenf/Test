﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using WelcomeAcademy6.DataModel;

namespace WelcomeAcademy6.BLogic
{
    internal class TupleSamples
    {
        internal void TupleSampleOne()
        {
            var tupleObject = new Tuple<string, int, string>("Claudia ", 47, "Test");
            Console.WriteLine(tupleObject.Item1);
            Console.WriteLine(tupleObject.Item2);
            Console.WriteLine(tupleObject.Item3);

            var person = ("claudio ", 47, "test");

            Console.WriteLine(person.Item1);
            Console.WriteLine(person.Item2);
            Console.WriteLine(person.Item3);

            Console.WriteLine();

            Worker worker = new() { Matricola = "v223", FullName = "Claudio Orioff", Role = MainEnumerators.Role.impiegato , Department = MainEnumerators.Department.UfficioAcquisti };
            Tuple<Worker, string, int, string> workerdata = new Tuple<Worker, string, int, string>(worker, "Claudio ", 47, " Mezzo");

            Console.WriteLine($"{workerdata.Item1.FullName}," + $"{workerdata.Item2}, {workerdata.Item3 } , {workerdata.Item4 } " );
        }
    }
}
