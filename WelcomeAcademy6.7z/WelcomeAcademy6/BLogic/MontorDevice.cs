﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelcomeAcademy6.BLogic
{
    internal abstract class MontorDevice
    {
        public int Xresolution { get; set; }

        public int Yresolution { get; set; }

        public int Zresolution { get; set; }


        public abstract int ComputePixelNumber();
        public abstract void PowerSystem();


        internal class MonitorDefinition : MontorDevice
        {
            public override int ComputePixelNumber()
            {
                throw new NotImplementedException();
            }


            public override void PowerSystem()
            {

            }


        }
    }
}
