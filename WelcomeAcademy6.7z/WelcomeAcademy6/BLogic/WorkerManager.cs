﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using WelcomeAcademy6.DataModel;
using System;
using System.Text.Json;
using System.Configuration;
using static WelcomeAcademy6.BLogic.WorkerManager;

namespace WelcomeAcademy6.BLogic
{

    #region Metodi Privati
    #endregion

    #region Metodi Pubblici

    
    // Commenti : lkdjfldsfjsdjfk


    /// <summary>
    /// Gestisce le operazioni sui lavoratori, inclusi inserimenti, ricerche e importazioni.
    /// </summary>
    public class WorkerManager
    {
        string lineSeparator = new(
            Convert.ToChar(ConfigurationManager.AppSettings["CharSeparator"]),
            Convert.ToInt32(ConfigurationManager.AppSettings["RepeatCharSeparator"]));
        private Worker worker = new();
        public List<Worker> Workers = [];
        public List<string> ListaErrata = [];
        public List<string> ListaErrata2 = [];
        /// <summary>
        /// Funzione per l'inserimento di un lavoratore
        /// </summary>
        /// <returns>Ritorna true/false se l'inserimento nella lista è riuscito</returns>
        public bool Insert()
        {
            bool result = false;
            bool isValidField = false;
            int xCursor = 0;
            int yCursor = 0;

            try
            {
                Console.Clear();
                Console.WriteLine("Inserimento Lavoratore");
                Console.WriteLine(lineSeparator);
                Console.Write("Inserire Numero Matricola: ");

                xCursor = Console.GetCursorPosition().Left;
                yCursor = Console.GetCursorPosition().Top;

                string matricola = string.Empty;
                while (!isValidField)
                {
                    matricola = Console.ReadLine();
                    if (matricola.Length == 4)
                    {
                        isValidField = true;
                    }
                    else
                    {
                        Console.WriteLine("Obblicatori 4 caratteri");
                        Console.SetCursorPosition(xCursor, yCursor);
                        Console.Write(new string(' ', matricola.Length));
                        Console.SetCursorPosition(xCursor, yCursor);
                    }
                }
                isValidField = false;
                string fullName = string.Empty;
                Console.Write("Inserire Nominativo completo: ");

                xCursor = Console.GetCursorPosition().Left;
                yCursor = Console.GetCursorPosition().Top;
                while (!isValidField)
                {
                    fullName = Console.ReadLine();
                    if (fullName.Length >= 3)
                    {
                        isValidField = true;
                    }
                    else
                    {
                        Console.WriteLine("Almeno tre caratteri");
                        Console.SetCursorPosition(xCursor, yCursor);
                        Console.Write(new string(' ', fullName.Length));
                        Console.SetCursorPosition(xCursor, yCursor);
                    }
                }

                isValidField = false;
                Console.Write("Inserire Ruolo aziendale (operaio/impiegato): ");


                xCursor = Console.GetCursorPosition().Left;
                yCursor = Console.GetCursorPosition().Top;
                string role = string.Empty;
                while (!isValidField)
                {
                    role = Console.ReadLine();
                    if (role.Length >= 3)
                    {
                        isValidField = true;
                    }
                    else
                    {
                        Console.WriteLine("Almeno tre caratteri");
                        Console.SetCursorPosition(xCursor, yCursor);
                        Console.Write(new string(' ', role.Length));
                        Console.SetCursorPosition(xCursor, yCursor);
                    }
                }
                isValidField = false;
                Console.Write("Inserire dipartimento: ");
                xCursor = Console.GetCursorPosition().Left;
                yCursor = Console.GetCursorPosition().Top;
                string department = string.Empty;
                while (!isValidField)
                {
                    department = Console.ReadLine();
                    if (department.Length >= 3)
                    { isValidField = true;}
                    else
                    {
                        Console.WriteLine("Almeno tre caratteri");
                        Console.SetCursorPosition(xCursor, yCursor);
                        Console.Write(new string(' ', department.Length));
                        Console.SetCursorPosition(xCursor, yCursor);
                    }
                }
                Console.Write("Inserire età (maggiore/uguale 18): ");
                _ = int.TryParse(Console.ReadLine(), out int validAge);
                int age = validAge;
                Console.WriteLine("Inserire indirizzo: ");
                string address = Console.ReadLine();
                Console.WriteLine("Inserire città: ");
                string city = Console.ReadLine();
                Console.WriteLine("Inserire provincia: ");
                string province = Console.ReadLine();
                Console.WriteLine("Inserire CAP: ");
                string cap = Console.ReadLine();
                Console.WriteLine("Inserire telefono: ");
                string phone = Console.ReadLine();

                MainEnumerators.Role role_;
                MainEnumerators.Department department_;

                if (Enum.TryParse(role, true, out role_) && Enum.IsDefined(typeof(MainEnumerators.Role), role_))
                {
                    //if role is valid y can still create a new object worker , 
                    worker = new Worker(matricola, fullName, role_, MainEnumerators.Department.AssemblaggioMotore, age, address, city, province, cap, phone);
                }
                else
                {
                    Console.WriteLine("Ruolo non valido. Riprova.");
                }


                worker.WorkDays.Add(new(1, DateTime.Now, "Trasferta", 9, matricola)); 
                Workers.Add(worker);
                result = true;
                Console.WriteLine("Lavoratore inserito correttamente");
                // Versione due per il caricamento worker nella lista e di seguito carcamento giornata lavorativa
                //Workers.Add(new(matricola, fullName, role, department, age, address, city, province, cap, phone));
                // potrei richiedere i dati della giornata di lavoro e inserirli sul worker appena creato
                //Workers[Workers.Count - 1].WorkDays.Add(new(1,DateTime.Now,"Trasferta",9, matricola));
            }
            catch (Exception ex)
            {
                Console.WriteLine($":ATTENZIONE: Errore imprevisto {ex.Message}");
            }
            return result;
        }
        /// <summary>
        /// Inserisce una giornata lavorativa per un lavoratore specificato dalla matricola.
        /// </summary>
        /// <param name="matricola">La matricola del lavoratore.</param>
        public void InsertWorkDays(string matricola = "")
        {
            if (string.IsNullOrEmpty(matricola))
            {
                Console.Write("Inserire la matricola del Worker ");
                matricola = Console.ReadLine();
                CercaLavoratorePerMatricola(matricola);
                Console.Clear();
                Console.WriteLine("Inserimento Giornata Lavorativa");
                Console.WriteLine(new string('-', 75));
                // Chiedere la data dell'attività
                Console.Write("Inserire la data dell'attività (gg/mm/aaaa): ");
                string dateString = Console.ReadLine();
                if (!DateTime.TryParse(dateString, out DateTime activityDate))
                {
                    Console.WriteLine("Data non valida. Riprova.");
                    return;
                }
                // Chiedere il tipo di attività
                Console.Write("Inserire tipo di attività: ");
                string jobType = Console.ReadLine();
                // Chiedere le ore totali
                Console.Write("Inserire ore totali lavorate: ");
                if (!int.TryParse(Console.ReadLine(), out int totalHours) || totalHours < 0)
                {
                    Console.WriteLine("Ore non valide. Riprova.");
                    return;
                }
                // Aggiungere la giornata lavorativa
                WorkDay newWorkDay = new WorkDay(1, activityDate, jobType, totalHours, matricola);
                worker.WorkDays.Add(newWorkDay);
                Console.WriteLine("Giornata lavorativa inserita correttamente.");
            }
        }
        /// <summary>
        /// Cerca un lavoratore per la matricola e visualizza i dettagli.
        /// </summary>
        /// <param name="matricola">La matricola da cercare.</param>
        public void CercaLavoratorePerMatricola(string matricola)
        {
            bool trovato = false;

            foreach (var lavoratore in Workers)
            {
                if (lavoratore.Matricola == matricola)
                {
                    Console.WriteLine($"Lavoratore trovato: Nome: {lavoratore.FullName}, Matricola: {lavoratore.Matricola}");
                    trovato = true;
                    break;
                }
            }

            if (!trovato)
            {
                Console.WriteLine("Lavoratore non trovato.");
            }
        }
        /// <summary>
        /// Cerca un lavoratore per il nominativo e visualizza i dettagli.
        /// </summary>
        /// <param name="nominativo">Il nominativo da cercare.</param>
        public void CercaLavoratorePerNominativo(string nominativo)
        {
            var lavoratoreTrovato = Workers.Find(l => l.FullName == nominativo);
            if (lavoratoreTrovato != null)
            {
                Console.WriteLine($"Lavoratore trovato: Nome: {lavoratoreTrovato.Matricola}, Nominativo: {lavoratoreTrovato.FullName}, Matricola: {lavoratoreTrovato.Matricola}");
            }
            else
            {
                Console.WriteLine("Lavoratore non trovato.");

            }
        }
        /// <summary>
        /// Importa i lavoratori da un file specificato.
        /// </summary>
        /// <param name="pathFile">Il percorso del file da cui importare i lavoratori.</param>
        public void ImportWorkersFile(string pathFile)
        {
            try
            {
                string[] strings = File.ReadAllLines(pathFile);

                foreach (string line in strings)
                {
                    string[] fields = line.Split(';');

                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("************");

                    if (fields.Length >= 10 && fields[0].Trim().Length == 4 ) // Assicurati che ci siano abbastanza colonn
                    {
                        string matricola = fields[0].Trim();
                        string fullName = fields[1].Trim();
                        string role = fields[2].Trim();
                        string department = fields[3].Trim();
                        int age = int.Parse(fields[4].Trim());
                        string address = fields[5].Trim();
                        string city = fields[6].Trim();
                        string province = fields[7].Trim();
                        string cap = fields[8].Trim();
                        string phone = fields[9].Trim();

                        // Crea un nuovo lavoratore e aggiungilo alla lista
                        Worker worker = new Worker(matricola, fullName, MainEnumerators.Role.operaio, MainEnumerators.Department.AssemblaggioMotore, age, address, city, province, cap, phone);
                       
                        Workers.Add(worker);
                    }
                    else
                    {
                        ListaErrata.Add(line);
                    }
                }

                Console.WriteLine("Lavoratori importati correttamente.");
            }
            catch (Exception ex) {
                Console.WriteLine($"Errore accesso File:  {ex.Message} ");
            }
        }
        public void ImportWorkDaysFile(string pathFile)
        {
            try
            {
                string[] lines = File.ReadAllLines(pathFile);

                foreach (string line in lines)
                {
                    string[] fields = line.Split(';');

                    if (fields.Length >= 4 && fields[3].Trim().Length == 4) // Controllo che la matricola sia di 4 caratteri
                    {
                        string matricola = fields[3].Trim();
                        DateTime activityDate = DateTime.Parse(fields[0].Trim());
                        string jobType = fields[1].Trim();
                        decimal totalHours = decimal.Parse(fields[2].Trim());
                        Worker worker = Workers.FirstOrDefault(w => w.Matricola == matricola);
                        if (worker != null)
                        {
                            WorkDay workDay = new WorkDay(1, activityDate, jobType, totalHours, matricola);
                            worker.WorkDays.Add(workDay);
                        }
                        else
                        {
                            Console.WriteLine($"Attenzione: Matricola {matricola} non trovata. Giornata lavorativa ignorata.");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Riga non valida: {line}");
                    }
                }

                Console.WriteLine("Giornate lavorative importate correttamente.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante l'importazione delle giornate lavorative: {ex.Message}");
            }
        }
        public void PrintListaErrata()
        {
            if (ListaErrata.Count > 0)
            {
                Console.WriteLine("Rigature errate:");
                foreach (string errata in ListaErrata)
                {
                    Console.WriteLine(errata);
                }
            }
            else
            {
                Console.WriteLine("Nessuna riga errata.");
            }
        }
        public void ImportWOrkersFromJson()
        {
            string savePath = ConfigurationManager.AppSettings["JsonFilePath"];

            try
            {
                string path_worker = File.ReadAllText(savePath);
                Workers = JsonSerializer.Deserialize<List<Worker>>(path_worker);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public void SaveWorkersToFile(bool saveJson)
        {
            string fileName = saveJson ? "Employees.json" : "SaveNewEmployees.txt";
            string savePath = ConfigurationManager.AppSettings["JsonFilePath"];

            //string SaveWorkers = string.Empty;
            StringBuilder SaveWorkers = new();
            string saveWorkersJson = string.Empty;

            try
            {
                foreach (Worker worker in Workers)
                {
                    SaveWorkers.AppendLine($"{worker.Matricola};{worker.FullName};{worker.Role}");
                }
                if (saveJson)
                {
                    fileName = "Employees.json";
                    saveWorkersJson = JsonSerializer
                        .Serialize(Workers, new JsonSerializerOptions { WriteIndented = true });

                    File.WriteAllText(Path.Combine(savePath, fileName), saveWorkersJson.ToString());
                }
                else
                { File.WriteAllText(Path.Combine(savePath, fileName), SaveWorkers.ToString()); }
            }
            catch (Exception ex)
            {
            }
        }
        public void ExportFilteredWorkersToJson(int minAge, int maxAge)
        {
            // Filtra i lavoratori con ore straordinarie
            // Filtra i lavoratori con ore straordinarie
            var filteredWorkers = Workers
                .Where(l => l.WorkDays.Any(w => w.TotalHours > 8 ))
                .Select(l => new
                {
                    Matricola = l.Matricola,
                    OreStandard = l.WorkDays
                        .Where(w => w.TotalHours <= 8 && w.JobType == "Ufficio")
                        .Sum(w => w.TotalHours),
                    OreExtra = l.WorkDays
                        .Where(w => w.TotalHours > 8)
                        .Sum(w => w.TotalHours - 8) // Sottraiamo 8 per calcolare solo le ore straordinarie
                })
                .ToList();
            string fileName = "FilteredEmployees.json";
            string savePath = "C:\\Users\\Betacom\\Desktop\\Employes";

            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(filteredWorkers, options);
                File.WriteAllText(Path.Combine(savePath, fileName), json);
                Console.WriteLine($"Lavoratori filtrati salvati in {fileName}. Contenuto:");
                Console.WriteLine(json); 
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante il salvataggio: " + ex.Message);
            }
        }
    public void RunLambdaExpressionAndLinq()
        {
            string workersFilePath = ConfigurationManager.AppSettings["WorkersFilePath"];
            ImportWorkersFile("workersFilePath");
            Console.WriteLine(lineSeparator);
            Console.WriteLine("Ricerca per matricola");
            Console.WriteLine(lineSeparator);
            Console.WriteLine(lineSeparator);
            Worker wk = Workers.Find(wk => wk.Matricola.Equals("I005 ", StringComparison.CurrentCultureIgnoreCase));
            if (wk != null)
            {
                ListaErrata.Add(wk.ToString()); 
            }
        }
        public void PrintWorkers()
        {
            MainEnumerators.Role specificRole = MainEnumerators.Role.operaio;
            //Workers.ForEach(w => Console.WriteLine($"Matricola: {w.Matricola}\nNominativo: {w.FullName}\nRuolo: {w.Role}\nDipartimento: {w.Department}\nEtà: {w.Age}\nIndirizzo: {w.Address}\nCittà: {w.City}\nProvincia: {w.Province}\nCAP: {w.Cap}\nTelefono: {w.Phone}"));
            foreach (Worker worker in Workers)
            {
                if (worker.Role == specificRole)
                {
                    Console.WriteLine($"Matricola: {worker.Matricola}");
                    Console.WriteLine($"Nominativo: {worker.FullName}");
                    Console.WriteLine($"Ruolo: {worker.Role}");
                    Console.WriteLine($"Dipartimento: {worker.Department}");
                    Console.WriteLine($"Età: {worker.Age}");
                    Console.WriteLine($"Indirizzo: {worker.Address}");
                    Console.WriteLine($"Città: {worker.City}");
                    Console.WriteLine($"Provincia: {worker.Province}");
                    Console.WriteLine($"CAP: {worker.Cap}");
                    Console.WriteLine($"Telefono: {worker.Phone}");
                    if (worker.WorkDays.Count > 0)
                    {
                        Console.WriteLine("Giornate lavorative:");
                        foreach (WorkDay workDay in worker.WorkDays)
                        {
                            Console.WriteLine($"Data: {workDay.ActivityDate}");
                            Console.WriteLine($"Tipo Attività: {workDay.JobType}");
                            Console.WriteLine($"Ore: {workDay.TotalHours}");
                            Console.WriteLine($"Matricola: {workDay.Matricola}");
                        }
                    }
                    else if (worker.Vacanze.Count > 0)
                    {
                        // Stampa le vacanze
                        Console.WriteLine("Vacanze:");
                        foreach (var vacanza in worker.Vacanze)
                        {
                            Console.WriteLine($"- Luogo: {vacanza.Luogo}, Periodo: {vacanza.Periodo}, Dettagli: {vacanza.Dettagli}");
                            foreach (var attivita in vacanza.AttivitaExtra)
                            {
                                Console.WriteLine($"Attività: {attivita.Key}, Costo: {attivita.Value} Euro");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("  Nessuna giornata lavorativa registrata.");

                    }
                }

                Console.WriteLine(lineSeparator);
                Console.WriteLine("******** LISTA EERRATA *************");
                Console.WriteLine(lineSeparator);
                PrintListaErrata();
            }
        }

        public class Vacanza : Worker 
        {
            public string id { get ; set; } 
            public string Luogo { get; set; }
            public (DateTime Inizio, DateTime Fine) Periodo { get; set; }
            public string TipoPensione { get; set; }
            public string Dettagli { get; set; }
            public Dictionary<string, decimal> AttivitaExtra { get; set; }


            static public List<(string Marca, string TipoCarburante, int Cilindrata, int Anno, string Incidenti)> Veicoli { get; set; } = new();
            static public Dictionary<DateTime, decimal> RilevazioniPeso { get; private set; } = new Dictionary<DateTime, decimal>();
            static public List<(string Luogo, string Periodo, string Dettagli)> Vacanze { get; private set; }


            public Vacanza()
            {
                AttivitaExtra = new Dictionary<string, decimal>();
            }
            public Vacanza(string id, string Luogo , DateTime Periodo, string TipoPensione,string Dettagli)
            {
                this.id = id;
                this.Luogo = Luogo;
                Periodo = Periodo;
                this.TipoPensione = TipoPensione;
                this.Dettagli = Dettagli;
            }
        }

        public Vacanza GestisciVacanze(string riga)
        {
            var campi = riga.Split(';');

            if (campi.Length < 5)
            {
                throw new ArgumentException("Riga non valida: " + riga);
            }
            var vacanza = new Vacanza
            {
                Luogo = campi[1].Trim(),
                Periodo = (DateTime.Parse(campi[3].Split('-')[0]), DateTime.Parse(campi[3].Split('-')[1])),
                TipoPensione = campi[4].Trim(),
                Dettagli = campi[5].Trim()
            };
            for (int i = 6; i < campi.Length; i++)
            {
                if (!string.IsNullOrWhiteSpace(campi[i]))
                {
                    var attivita = campi[i].Split(',');
                    foreach (var att in attivita)
                    {
                        var attivitaDettagli = att.Trim().Split(';');
                        if (attivitaDettagli.Length == 2)
                        {
                            var nomeAttivita = attivitaDettagli[0].Trim();
                            if (decimal.TryParse(attivitaDettagli[1].Trim().Replace("Euro", "").Replace("€", ""), out var prezzo))
                            {
                                vacanza.AttivitaExtra[nomeAttivita] = prezzo;
                            }
                        }
                    }
                }
            }
            foreach (var attivita in vacanza.AttivitaExtra)
            {
                Console.WriteLine($"-{attivita.Key}:{attivita.Value} Euro");
            }
            return vacanza;
        }

        public void ImportaVacanze(string filePath)
        {
            try
            {
                var vacanze = new List<Vacanza>();
                var righe = File.ReadAllLines(filePath);

                foreach (var riga in righe)
                {
                    if (riga.StartsWith("Vacanze"))
                    {
                        var vacanza = GestisciVacanze(riga);
                        vacanze.Add(vacanza);
                    }
                    else
                    {
                        if (vacanze.Count > 0) 
                        {
                            var attivita = riga.Split(';');
                            if (attivita.Length == 2)
                            {
                                var nomeAttivita = attivita[0].Trim();
                                if (decimal.TryParse(attivita[1].Trim().Replace("Euro", "").Replace("€", ""), out var prezzo))
                                {
                                    vacanze[vacanze.Count - 1].AttivitaExtra[nomeAttivita] = prezzo; 
                                }
                            }
                        }
                    }
                }
                StampaVacanze(vacanze);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante l'importazione delle vacanze: {ex.Message}");
            }
        }
        private void StampaVacanze(List<Vacanza> vacanze)
        {
            foreach (var vacanza in vacanze)
            {
                Console.WriteLine($"Luogo: {vacanza.Luogo}");
                Console.WriteLine($"Periodo: {vacanza.Periodo.Item1.ToShortDateString()} - {vacanza.Periodo.Item2.ToShortDateString()}");
                Console.WriteLine($"Tipo di pensione: {vacanza.TipoPensione}");
                Console.WriteLine($"Dettagli: {vacanza.Dettagli}");
                Console.WriteLine("Attività Extra:");

                foreach (var attivita in vacanza.AttivitaExtra)
                {
                    Console.WriteLine($"- {attivita.Key}: {attivita.Value} Euro");
                    
                }

                Console.WriteLine();
            }
        }
            public void ImportaDati(string pathRilevazioni, string pathVeicoli, string pathVacanze)
        {
            ImportaRilevazioniPeso(pathRilevazioni);
            ImportaVeicoli(pathVeicoli);
            ImportaVacanze(pathVacanze);
        }

        static public void ImportaRilevazioniPeso(string filePath)
        {
            try
            {
                string[] righe = File.ReadAllLines(filePath);
                foreach (var riga in righe)
                {
                    var campi = riga.Split(';');
                    if (campi.Length == 2 &&
                        DateTime.TryParse(campi[0], out DateTime data) &&
                        decimal.TryParse(campi[1], out decimal peso))
                    {
                        Vacanza.RilevazioniPeso.Add(data, peso);
                        var rilevazioneordinate =Vacanza.RilevazioniPeso.OrderBy(x => x.Value).ToList();
                        foreach (var entry in rilevazioneordinate)
                        {
                            Console.WriteLine($"Data: {entry.Key.ToShortDateString()}, Peso: {entry.Value}");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Riga non valida o matricola non corrispondente in Rilevazioni Peso: {riga}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante l'importazione delle rilevazioni: {ex.Message}");
            }
        }
        /// <summary>
        /// Importo i dati del worker Conetenti dati di veicoli
        /// </summary>
        /// <param name="filePath"></param>
        static public void ImportaVeicoli(string filePath)
        {
            foreach (var riga in File.ReadLines(filePath))
            {
                var campi = riga.Split(';');
                if ( 
                    int.TryParse(campi[1].Trim(), out int cilindrata) &&
                    int.TryParse(campi[2].Trim(), out int anno))
                {
                    Vacanza.Veicoli.Add((campi[1].Trim(), campi[4].Trim(), cilindrata, anno, campi[5].Trim()));
                  
                }
            }
        }
        static public void AggiornaFileVeicoli(string filePath, string matricola)
        {
            var righeAggiornate = new List<string>();
            foreach (var riga in File.ReadLines(filePath))
            {
                // Sostituisci le virgole con punti e virgola
                var rigaCorretta = riga.Replace(',', ';');
                var campi = rigaCorretta.Split(';');
                // Assicurati che ci siano esattamente 5 campi
                if (campi.Length == 5)
                {
                    // Aggiungi la matricola all'inizio della riga
                    righeAggiornate.Add($"{matricola};{campi[0]};{campi[1]};{campi[2]};{campi[3]};{campi[4]}");
                }
                else
                {
                    Console.WriteLine($"Riga non valida: {rigaCorretta} (numero di campi: {campi.Length})");
                }
            }

            // Scrivi le righe aggiornate nel file
            File.WriteAllLines(filePath, righeAggiornate);
        }
        static public void AggiornaDieta(string filePath, string matricola)
        {
            var righeAggiornate = new Dictionary<string, int>();
            // Leggi il file riga per riga
            foreach (var riga in File.ReadLines(filePath))
            {
                var campi = riga.Split(';');
                // Verifica se la riga ha un numero sufficiente di campi
                if (campi.Length >= 2) // Assumendo che il secondo campo sia il valore da associare
                {
                    // Prova a parsare il valore come intero
                    if (int.TryParse(campi[1].Trim(), out int valore))
                    {
                        // Aggiungi la matricola e il valore al dizionario
                        righeAggiornate[matricola] = valore; // Sovrascrive se esiste già
                    }
                    else
                    {
                        Console.WriteLine($"Valore non valido nella riga: {riga}");
                    }
                }
                else
                {
                    Console.WriteLine($"Riga non valida: {riga}");
                }
            }
        }
        public void StampaVeicoli()
        { 
            foreach (var veicolo in Vacanza.Veicoli)
            {
                Console.WriteLine($"Marca: {veicolo.Marca},Tipo Carburante: {veicolo.TipoCarburante}, Cilindrata: {veicolo.Cilindrata}, Anno: {veicolo.Anno}, Incidenti: {veicolo.Incidenti}");
            }
        }
        public void EseguiConteggioCaratteriSpeciali(string filePath)
        {
            try
            {
                int totalSpecialCharacters = ContaCaratteriSpeciali(filePath);
                Console.WriteLine($"Il numero totale dei caratteri speciali nel file è: {totalSpecialCharacters}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Si è verificato un errore: {ex.Message}");
            }
        }
        public int ContaCaratteriSpeciali(string filePath)
        {
            int count = 0;

            foreach (var riga in File.ReadLines(filePath))
            {
                count += ContaOccorrenze(riga);
            }

            return count;
        }

      static int ContaOccorrenze(string riga)
        {
            int count = 0;

            foreach (char c in riga)
            {
                if (!char.IsLetterOrDigit(c) && !char.IsWhiteSpace(c))
                {
                    count++;
                }
            }
            return count;
        }





    }

#endregion
}