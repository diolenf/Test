﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelcomeAcademy6.BLogic
{
    internal class RefSample
    {
        internal void MultiplyNumber(int num)
        {
            int mynmber = num;
            Console.WriteLine($"Valore iniziale di myNumber: {mynmber}.");
            MultiplyNumber2(mynmber);
            Console.WriteLine($"Valore dopo  MultiplyNumber2 di myNumber:{mynmber}.");
            MultiplyNumberRef(ref mynmber);
            Console.WriteLine($"Valore dopo Ref di myNumber:{mynmber}");
        }
        internal void MultiplyNumber2(int num)
        {
            num *= num;
            //Console.WriteLine($"Il quadrato di {num} tramite passaggio per riferimento é {num}");
        }
        internal void MultiplyNumberRef(ref int num)
        {
            num *=  num;
            //Console.WriteLine($"Il quadrato di {num} tramite passaggio per riferimento é {num}");
        }
    }
}
