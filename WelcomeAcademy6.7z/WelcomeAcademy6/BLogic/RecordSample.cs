﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelcomeAcademy6.BLogic
{
    internal class RecordSample
    {
       internal record Person(string fullname,string email,string phone)
        {
            private string FullName => fullname;
            private  string Email => email;
            private  string Phone  => phone;

            internal Person ChangeUpperCaseValues()
            {
                return new Person(FullName.ToUpper(), Email, Phone); 
            }

            internal record Rec2(string fullname, string email, string phone) :Person("j","kl","121")
            {

            }

        }

    }
}
