﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelcomeAcademy6.BLogic
{
    internal class CointainALlExtendWorkManager
    {
        public class ContainAll : WorkerManager 
        {
            static public List<(string Marca, string TipoCarburante, int Cilindrata, int Anno, string Incidenti)> Veicoli { get; set; } = new();
            static public Dictionary<DateTime, decimal> RilevazioniPeso { get; private set; }
            static public List<(string Luogo, string Periodo, string Dettagli)> Vacanze { get; private set; }

            public void CercaLavoratorePerMatricola(string matricola)
            {
                bool trovato = false;

                foreach (var lavoratore in Workers)
                {
                    if (lavoratore.Matricola == matricola)
                    {
                        Console.WriteLine($"Lavoratore trovato: Nome: {lavoratore.FullName}, Matricola: {lavoratore.Matricola}");
                        trovato = true;
                        break;
                    }
                }

                if (!trovato)
                {
                    Console.WriteLine("Lavoratore non trovato.");
                }
            }

        }




    }
}
