﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IO;


namespace WelcomeAcademy6.BLogic
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class FileAnalyzer
    {
        public char TrovaSeparatore(string filePath)
        {
            // Dizionario per contare le occorrenze di ogni carattere
            Dictionary<char, int> conteggioCaratteri = new Dictionary<char, int>();

            foreach (var riga in File.ReadLines(filePath))
            {
                foreach (char c in riga)
                {
                    if (!char.IsLetterOrDigit(c) && !char.IsWhiteSpace(c)) 
                    {
                        if (conteggioCaratteri.ContainsKey(c))
                        {
                            conteggioCaratteri[c]++;
                        }
                        else
                        {
                            conteggioCaratteri[c] = 1;
                        }
                    }
                }
            }
            var carattereSeparatore = conteggioCaratteri.OrderByDescending(kvp => kvp.Value).FirstOrDefault();
            Console.WriteLine("Conteggio dei caratteri speciali trovati nel file:");
            foreach (var kvp in conteggioCaratteri)
            {
                Console.WriteLine($"Carattere: '{kvp.Key}' - Occorrenze: {kvp.Value}");
            }

            return carattereSeparatore.Key; 
        }

        public void EseguiAnalisi(string filePath)
        {
            try
            {
                char separatore = TrovaSeparatore(filePath);
                Console.WriteLine($"Il carattere separatore identificato è: '{separatore}'");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Si è verificato un errore: {ex.Message}");
            }
        }
    }


}