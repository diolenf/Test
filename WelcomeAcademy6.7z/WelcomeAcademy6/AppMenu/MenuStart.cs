﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WelcomeAcademy6.DataModel;
using WelcomeAcademy6.BLogic;
using System.Configuration;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace WelcomeAcademy6.AppMenu
{
    public static class MenuStart
    {
        public static void Show()
        {
        bool exitLoop = false;
        string lineSeparator = new(
          Convert.ToChar(ConfigurationManager.AppSettings["CharSeparator"]),
          Convert.ToInt32(ConfigurationManager.AppSettings["RepeatCharSeparator"]));
            WorkerManager workerManager = new();

            try
            {
                while (!exitLoop)
                {
                    Console.Clear();
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("Benvenuto in Academy6 Corporation");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine();
                    Console.WriteLine("1. Inserimento Lavoratore");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("2. Inserimento Settimana Lavorativa");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("3. Eliminazione Lavoratore --> giorno lavorativo");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("4. Visualizzazione Lavoratori");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("5. Ricerca Lavoratore --> Matricola, Nominativo, Giorno lavorativo");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("6. Inserimento WorkersFile ");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("7. Esci");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("8.Salva Elenco Lavoratori su File Esterno");
                    Console.WriteLine(lineSeparator);
                    Console.WriteLine("9.Storia Utente");
                    Console.WriteLine(lineSeparator);
                    Console.Write("Eseguire scelta da 1 a 9: ");


                    //ConsoleKeyInfo sceltaString = Console.ReadKey();
                    string sceltaString = Console.ReadLine();
                    bool resultChoice = int.TryParse(sceltaString, out int scelta);
                    if (resultChoice && Enum.IsDefined(typeof(MainEnumerators.StartMenuFunctions), scelta))
                    {
                        var funzioneScelta = (MainEnumerators.StartMenuFunctions)scelta; //<cast-type-enum-int >
                        switch (funzioneScelta)
                        {
                            case MainEnumerators.StartMenuFunctions.InsertWorker:
                                workerManager.Insert();
                                break;
                            case MainEnumerators.StartMenuFunctions.InsertWorkerWeek:
                                workerManager.InsertWorkDays("");
                                Console.WriteLine("\nInserimento Settimana Lavorativa");
                                break;
                            case MainEnumerators.StartMenuFunctions.DeleteWorker:
                                Console.WriteLine("\nEliminazione Lavoratore --> giorno lavorativo||test");
                                //WorkerManager.ImportaVeicoli("C:\\Users\\Betacom\\Desktop\\Employes\\InfoMarioRossi\\MezziDisposizione.txt");
                                //WorkerManager.AggiornaFileVeicoli("C:\\Users\\Betacom\\Desktop\\Employes\\InfoMarioRossi\\MezziDisposizione.txt","I005");
                                WorkerManager.AggiornaDieta("C:\\Users\\Betacom\\Desktop\\Employes\\InfoMarioRossi\\RilevazionePeso.txt", "I005");
                                //WorkerManager.ImportaRilevazioniPeso("C:\\Users\\Betacom\\Desktop\\Employes\\InfoMarioRossi\\RilevazionePeso.txt");
                                //workerManager.ImportaVacanze("C:\\Users\\Betacom\\Desktop\\Employes\\InfoMarioRossi\\Vacanze2023.txt");
                                break;
                            case MainEnumerators.StartMenuFunctions.ShowWorkers:
                                //WorkerManager.AggiornaDieta("C:\\Users\\Betacom\\Desktop\\Employes\\InfoMarioRossi\\RilevazionePeso.txt", "I005");
                                //WorkerManager.AggiornaFileVeicoli("C:\\Users\\Betacom\\Desktop\\Employes\\InfoMarioRossi\\MezziDisposizione.txt","I005");
                                workerManager.PrintWorkers();
                                
                                break;
                            case MainEnumerators.StartMenuFunctions.SearchWorkers:
                                Console.WriteLine("Inserisci la matricola del lavoratore da cercare:");
                                string matricola = Console.ReadLine();
                                workerManager.CercaLavoratorePerMatricola(matricola);
                                Console.WriteLine("\nRicerca Lavoratore --> Matricola, Nominativo, Giorno lavorativo");
                                break;
                            case MainEnumerators.StartMenuFunctions.ImportWorkers:
                                // Percorsi dei file
                                string workersFilePath = ConfigurationManager.AppSettings["WorkersFilePath"]; // File dei lavoratori
                                string workDaysFilePath = ConfigurationManager.AppSettings["WorkDaysFilePath"]; // File delle giornate lavorative
                                // Importa i lavoratori
                                workerManager.ImportWorkersFile(workersFilePath);
                                Console.WriteLine("Lavoratori importati con successo.");
                                // Importa le giornate lavorative
                                workerManager.ImportWorkDaysFile(workDaysFilePath);
                                Console.WriteLine("Giornate lavorative importate con successo.");
                                break;
                            case MainEnumerators.StartMenuFunctions.ExitProgram:
                                Console.WriteLine("\nUscita dal programma");
                                exitLoop = true;
                                break;
                            case MainEnumerators.StartMenuFunctions.SaveWorkersList:
                                bool saveJson = false;
                                Console.Write("\nSalvataggio su file Json? (S/N): ");
                                string choiceValue = Console.ReadLine();
                                saveJson = choiceValue.ToUpper() == "S" ? true : false;
                                //workerManager.ImportWOrkersFromJson();
                                workerManager.ExportFilteredWorkersToJson(40, 50);
                                break;
                            case MainEnumerators.StartMenuFunctions.StoryInfo:
                                workerManager.EseguiConteggioCaratteriSpeciali("C:\\Users\\Betacom\\Desktop\\Employes\\Employees.txt");
                                break;
                            default:
                                Console.WriteLine("\nScelta non valida");
                                break;
                        }

                        Console.WriteLine("Premere un tasto per continuare");
                        _ = Console.ReadKey();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($":ATTENZIONE: Errore imprevisto {ex.Message}");
            }
        }
    }
}