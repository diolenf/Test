﻿using WelcomeAcademy6.AppMenu;
using WelcomeAcademy6.BLogic;
using static WelcomeAcademy6.BLogic.RecordSample;

namespace WelcomeAcademy6
{
    internal class Program
    {
        //static void Main(string[] args) => MenuStart.Show();
        static void Main(string[] args)
        {
            //DictionarySamples dictionarySamples = new DictionarySamples();
            //dictionarySamples.FirstDictionary();

            //TupleSamples tupleSamples = new TupleSamples();
            //tupleSamples.TupleSampleOne();
            //RecordSample.Person person = new("test ", "ACADEMY@GMAIL.COM", "3217277171");
            //Console.WriteLine(person.ChangeUpperCaseValues());

            // (string nome, string posta, string tele) = person;
            // Console.WriteLine(nome);
            //;

            FileAnalyzer analyzer = new FileAnalyzer();
            analyzer.EseguiAnalisi("C:\\Users\\Betacom\\Desktop\\Employes\\Employees.txt");

            //MenuStart.Show();

        }
    }
}
